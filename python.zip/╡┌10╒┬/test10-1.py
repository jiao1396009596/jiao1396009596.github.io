class test:
    def show(self):
        print(self.data)#1
x=test()
x.data=100#2
x.show()
