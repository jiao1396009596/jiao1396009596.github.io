class test:
    data=0#1
x=test()
y=test()
x.data=100
test.data=20
print(x.data,y.data,test.data)#2
