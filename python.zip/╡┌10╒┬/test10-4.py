class test:
    def __init__(self):#1
        self.name="None"
        self.age=0
x=test()#2
print(x.name,x.age)
