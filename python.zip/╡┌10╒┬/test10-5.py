class test:
    @staticmethod#1
    def mul(a,b):#2
        return a*b
x=test()
print(x.mul(2,3),test.mul(4,5))
