'''
//改错题
x=-5
if x>0:
print(x,'是正数')
  else:print(x,'不是正数')
'''
#改错题（1）
x=-5
if x>0:
    print(x,'是正数')	#（2）
else:print(x,'不是正数')#（3）
