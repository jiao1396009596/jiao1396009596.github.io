a,*b=eval(input('请输入多个数据：'))
print('和=',a+sum(b))
