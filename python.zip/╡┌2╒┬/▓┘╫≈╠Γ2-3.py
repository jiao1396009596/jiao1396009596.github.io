a=eval(input('请输入第1个数：'))
b=eval(input('请输入第2个数：'))
print('交换前：a=',a,' b=',b)
a,b=b,a                       	#添加的语句
print('交换后：a=',a,' b=',b)
