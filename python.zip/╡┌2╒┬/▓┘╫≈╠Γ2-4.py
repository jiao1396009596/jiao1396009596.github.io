print('优雅')
print('明确')
print('简单')
