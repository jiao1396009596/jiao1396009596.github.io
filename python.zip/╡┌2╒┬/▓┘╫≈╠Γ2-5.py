a=1
b=2
c=3
print(a,b,c,sep=',')
