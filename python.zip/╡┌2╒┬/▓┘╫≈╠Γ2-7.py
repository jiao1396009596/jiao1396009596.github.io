a=eval(input('请输入一个数据：'))
print(a,type(a))
