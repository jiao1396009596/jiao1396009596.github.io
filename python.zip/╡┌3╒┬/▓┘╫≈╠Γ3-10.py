n=4
m=5
while n>=1:    
    print('{}{}'.format(' '*m,'*'*(2*n-1)))
    n-=1
    m+=1
