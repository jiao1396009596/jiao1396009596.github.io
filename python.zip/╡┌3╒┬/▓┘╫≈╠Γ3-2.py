a,b=eval(input('请输入两个整数：'))
y=a%b
x=int(a/b)
print(a,'除以',b,'的商：',x)
print(a,'除以',b,'的余数：',y)
