a=eval(input('请输入一个不大于255的正整数：'))
print('  二进制：{:08b}'.format(a))
print('  八进制：{:08o}'.format(a))
print('十六进制：{:08X}'.format(a))
