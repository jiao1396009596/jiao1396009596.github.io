a=input('请输入一串字符：')
c=max(a)
print('最大字符为：%c，其位置为：%d'%(c,a.index(c)))
