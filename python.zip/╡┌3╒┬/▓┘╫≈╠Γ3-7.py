a=input('请输入多种水果名称：')
b=a.replace(' ','\n')
print(b)
