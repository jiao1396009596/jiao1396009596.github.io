a=input('请输入一个词语：')
print('{:_^20}'.format(a))
