n=eval(input('请输入n：'))
x=2
while x//2<=n:#①
   print(x,end=' ')
   x+=2#②

