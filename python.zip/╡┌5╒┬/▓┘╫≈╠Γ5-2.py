s=0#①
for n in range(1,101):#②
   s+=n
print('1+2+...+100=',s)
