from turtle import *	#①
color("red", "blue")
begin_fill()
for n in range(3):
  fd(100)
  lt(120)
end_fill()#②
