from turtle import *
write('(0,0)')
for n in range(4):
  fd(200)#①
  lt(90)
goto(100,0)#②
circle(100)
