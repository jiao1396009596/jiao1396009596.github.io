from turtle import *
pensize(2)			#设置画笔宽度
fd(180)				#绘制长边,长度为矩形的长减去两个圆角的半径
circle(10,90)			#绘制90度圆角
fd(80)				#绘制短边, 长度为矩形的宽减去两个圆角的半径
circle(10,90)
fd(180)
circle(10,90)
fd(80)
circle(10,90)
